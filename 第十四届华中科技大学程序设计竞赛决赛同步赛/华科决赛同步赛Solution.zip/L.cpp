#include <bits/stdc++.h>

typedef long long ll;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef long double db;
typedef unsigned char uchar;

using namespace std;

#define var auto
#define range(i,a,b) for(int i=a; i<=(b); i++)
#define revr(i,a,b) for(int i=a; i>=(b); i--)
#define prln putchar('\n')
#define prsp putchar(' ')
#define pri(i) printf("%d", (i))
#define prl(i) printf("%lld", (i))
#define cp(dst,src,len) memcpy((&dst), (&src), sizeof(src[0]) * (len))

template<typename T> void read(T& x)
{
    x = 0;
    bool mi = false;
    char c = getchar();
    while(c != EOF && !isdigit(c) && c != '-') c = getchar();
    if(c == '-') { mi = true; c = getchar(); }
    do { x = x * 10 + c - '0'; } while((c = getchar()) != EOF && isdigit(c));
    if(mi) x = -x;
}
inline int getint() { int x; read(x); return x; }
inline ll getll() { ll x; read(x); return x; }
db getdb() { static double x; scanf("%lf",&x); return x; }

// ==================================================================================-=====

db v, g, d, h, k;

db eps = 1e-12;
bool eq(db a, db b) { return abs(a - b) < eps; }

struct point
{
    db x,y;
    db len() const { return sqrt(x*x + y*y); }
    point operator()(point const&v) const { return point{v.x-x, v.y-y}; }
};

point s;

static db BiSearch(db l, db r, function<db(db)> const& f)
{
    if(f(l) > f(r)) swap(l, r);
    range(i, 0, 52)
    {
        db mid = 0.5 * (l + r);
        if(f(mid) < 0) l = mid;
        else r = mid;
    }
    return 0.5 * (l + r);
}

static db TrSearch(db l, db r, function<db(db)> const& f)
{
    range(i, 0, 64)
    {
        db cl = 0.25 * l + 0.75 * r;
        db cr = 0.75 * l + 0.25 * r;
        db fl = f(cl);
        db fr = f(cr);
        if(fl > fr) l = cl;
        else r = cr;
    }
    return 0.5 * (l + r);
}

static bool HasSol(db l, db r, function<db(db)> const& f) { return f(l) * f(r) < eps; }
static db R(db x) { return k * x; }
static db H(db x) { return v + R(x); }
static db Y(db x) { db t = fmod(H(x), 2.0); return t > 1.0 ? 2.0 - t : t;  }
static db D(db x) { return sqrt(R(x)*R(x) + x*x) + point{x, Y(x)}(s).len(); }
static db F(db x) { return D(x) - d; }

db ansx = -1e20;

static bool FindAns(db l, db r)
{
    db xi = TrSearch(l, r, F);
    db fl = F(l);
    db fr = F(r);
    if((fl < -eps && fr < -eps) || (fl > eps && fr > eps)) return false;
    db li = BiSearch(l, xi, F);
    if(eq(F(li), 0)) { ansx = li; return true; }
    db ri = BiSearch(xi, r, F);
    if(eq(F(ri), 0)) { ansx = ri; return true; }
    return false;
}

int main()
{
    v = getdb();
    
    g = getdb();
    h = getdb();
    k = h / g;
    
    db I0 = getdb();
    db I = getdb();
    
    
    d = sqrt(I0 / I);
    
    s.x = getdb();
    s.y = getdb();
    
    // printf("%.8f %.8f %.8f %.8f %.8f\n", v, g, h, s.x, s.y);
    
    db step = g / h;
    db bg = (1 - v) * k;
    
    // printf("v:%.6f\n", v);
    // printf("g:%.6f h:%.6f k:%.6f\n", g, h, k);
    // printf("I0:%.6f I:%.6f D:%.6f\n", I, I0, d);
    // printf("s(%.6f, %.6f)\n", s.x, s.y);
    
    FindAns(0, bg);
    db x;
    
    // printf("%.8f\n", s.x + k + eps);
    
    int cnt = 0;
    if(ansx == -1e20) for(x = bg; !FindAns(x, x+step) && x <= s.x + k + eps; x += step, cnt++);
    if(ansx == -1e20) FindAns(x, 1e4);
    
    // printf("%.6f\n", ansx);
    if(ansx == -1e20) printf("None\n");
    else
    {
        printf("%.12f\n", (double)ansx);
        assert(eq(D(ansx), d));
    }
    
    return 0;
}
