#include<cstdio>
#include<cstring>
#include<iostream>

using namespace std;

long long ans,n,k;

int main()
{
    while(scanf("%lld%lld",&n,&k)!=EOF)
    {        
        ans=0;
        for(long long i=0;i<n*k;i+=(i/n)+1)ans++;
        printf("%lld\n",ans);
    }
    
    return 0;
}