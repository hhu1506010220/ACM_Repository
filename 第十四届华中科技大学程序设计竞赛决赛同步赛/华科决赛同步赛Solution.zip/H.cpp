#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <climits>
#include <vector>
#include <map>
using namespace std;
#define N 100100
typedef long long ll;
int n,K,P,w[N];
int sz[N],f[N];
int in[N],ou[N],up[N],need[N],down[N];
int pw[N],inv[N];
int q[N],top,dep[N];
struct E{
	int v,n;
}G[N*2];
int cnt,point[N];
bool vis[N];
ll ans(0);
vector<int> son[N];
map<int,int>from,to;
void addedge(int u,int v){
    G[++cnt] = (E){v,point[u]},point[u]=cnt;
}
ll power(ll x,ll k){
	ll res(1);
	for(;k;k>>=1){
		if(k&1)res=res*x%P;
		x=x*x%P;
	}
	return res;
}
void dfs_sz(int x,int fa){
    sz[x]=1;f[x]=0;q[++top]=x;
    for(int i=point[x];i;i=G[i].n)
        if(!vis[G[i].v]&&G[i].v!=fa){
            int v(G[i].v);
            dfs_sz(v,x);
            sz[x]+=sz[v];
            f[x]=max(f[x],sz[v]);
        }
}
int find_focus(int x){
	top=0;dfs_sz(x,0);
    int res,tmp(INT_MAX);
    for(int i=1;i<=top;i++){
        int t=max(sz[x]-sz[q[i]],f[q[i]]);
        if(t<tmp)tmp=t,res=q[i];
    }
    return res;
}
void dfs(int x,int fa){
    for(int i=point[x];i;i=G[i].n)
        if(!vis[G[i].v]&&G[i].v!=fa){
            int v(G[i].v);
            dep[v]=dep[x]+1;
            up[v]=((ll)up[x]*(ll)K%P+(ll)w[v])%P;
            down[v]=(down[x]+(ll)w[v]*(ll)pw[dep[v]])%P;
            dfs(v,x);
        }
}
void get_sons(int x,int fa,int anc){
    son[anc].push_back(x);
    for(int i=point[x];i;i=G[i].n)
        if(!vis[G[i].v]&&G[i].v!=fa)
            get_sons(G[i].v,x,anc);
}
int ask(map<int,int> &m,int x){
	if(m.find(x) != m.end())return m[x];
    return 0;
}
void add(map<int,int> &m,int x,int f){
	if(m.find(x) != m.end())m[x] += f;
    else m[x]=f;
}
void calc(){
    from.clear();to.clear();
    for(int i=1;i<=top;i++)
        for(auto j=son[q[i]].begin();j!=son[q[i]].end();j++)
            add(to,down[*j],1);
    for(int i=1;i<=top;i++){
        vector<int> &x=son[q[i]];
		for(auto j:x)
            add(to,down[j],-1);
		for(auto j:x){
            ou[j]+=ask(to,need[j]);
            in[j]+=ask(from,down[j]);
        }
		for(auto j:x)
            add(from,need[j],1);
    }
}
void solve(int x){
    vis[x=find_focus(x)]=1;
    up[x]=down[x]=w[x];dep[x]=0;
    dfs(x,0);
    for(int i=1;i<=top;i++)
        if(q[i]==x){
			if(up[x]==0)
				ou[x]++,in[x]++;
		}
        else{
            if(up[q[i]]==0)
				in[x]++,ou[q[i]]++;
            if(down[q[i]]==0)
				ou[x]++,in[q[i]]++;
        }top=0;
    for(int i(point[x]);i;i=G[i].n)
        if(!vis[G[i].v]){
            int v(G[i].v);
            q[++top]=v;son[v].clear();get_sons(v,0,v);
			for(auto j:son[v])
                need[j]=((P-up[j])*(ll)inv[dep[j]]+w[x])%P;
        }
    calc();
    reverse(q+1,q+top+1);
    calc();
    for(int i=point[x];i;i=G[i].n)
        if(!vis[G[i].v])
            solve(G[i].v);
}
int main(){
    scanf("%d %d %d", &n, &K, &P);
    for(int i=1;i<=n;i++)
		scanf("%d", &w[i]), w[i]%=P;
    for(int i=1,u,v;i<n;i++){
	    scanf("%d %d", &u, &v);
        addedge(u,v);
        addedge(v,u);
    }
    for(int i=pw[0]=1;i<=n;i++){
    	pw[i]=(pw[i-1]*(ll)K)%P;
    	inv[i]=power(pw[i],P-2);
    }
	f[0]=INT_MAX;
    solve(1);
    for(int i=1;i<=n;i++){
    	ans+=((ll)in[i]*ll(n-in[i]))<<1;
    	ans+=((ll)ou[i]*ll(n-ou[i]))<<1;
    	ans+=(ll)in[i]*ll(n-ou[i])+(ll)ou[i]*ll(n-in[i]);
    }
    ans=(ll)n*n*n-(ans>>1);
    printf("%lld\n", ans);
    return 0;
}
