#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;

const int maxn = 105;
vector<int> vi;
bool cmp(int x, int y){
    return x > y;
}

int main()
{
    int n, m, x = 0, y = 0;
    cin >> n;
    for(int i = 0; i < n; i++){
        cin >> m;
        int rd;
        for(int j = 0; j < m; j++){
            cin >> rd;
            if(j < m/2) x += rd;
            if(j > (m-1)/2) y += rd;
            if(j == m/2 && (m & 1)) vi.push_back(rd);
        }
    }
    sort(vi.begin(), vi.end(), cmp);
    for(int i = 0; i < vi.size(); i++){
        if(i & 1) y += vi[i];
        else      x += vi[i];
    }
    cout << x << " " << y << endl;
    return 0;
}
