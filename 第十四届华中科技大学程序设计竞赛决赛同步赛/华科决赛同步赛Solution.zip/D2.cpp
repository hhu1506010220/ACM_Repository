#include <bits/stdc++.h>
using namespace std;
#define zeros(a,n) memset(a,0,(n)*sizeof(a[0]))
typedef long long LL;
typedef unsigned long long ULL;
const LL modn = 998244353;
int mod(int x) { return x<0?x+modn:x<modn?x:x-modn; }

#define debug(a, n) do{cout<<#a; \
    for(int i=0; i<(n); i++) \
        cout<<' '<<a[i]; \
    cout<<endl; }while(false)

const int maxn = 3000 + 9, maxl = 2000 + 9;
vector<int> edge[maxn];
int dp[maxn][maxl];
int val[maxn];
int ans[maxl];
bool vis[maxn];

int getdiam(int x, int on)
{
    static int fa[maxn], q[maxn];
    int qf=0, qe=0;
    fa[x] = 0;
    q[qe++] = x;
    while(qf < qe) {
        x = q[qf++];
        for(int y: edge[x]) {
            if(vis[y] || y == fa[x]) continue;
            fa[y] = x;
            q[qe++] = y;
        }
    }
    if(on) {
        int len = 0;
        for(int i=x; i; i=fa[i]) len++;
        for(int i=len>>1; i; i--) x = fa[x];
    }
    return x;
}

void solve(int x, int f = 0)
{
    copy(dp[f], dp[f]+maxl-val[x], dp[x] + val[x]);
    fill(dp[x], dp[x]+val[x], 0);
    for(int y: edge[x]) {
        if(vis[y] || y == f) continue;
        solve(y, x);
        for(int i=0; i<maxl; i++)
            dp[x][i] = mod(dp[x][i] + dp[y][i]);
    }
}
void divide(int x)
{
    x = getdiam(x, 0);
    x = getdiam(x, 1);
    vis[x] = true;
    solve(x);
    for(int y: edge[x]) {
        if(vis[y]) continue;
        divide(y);
    }
}

int main()
{
    dp[0][0] = 1;
    int n; scanf("%d", &n);
    for(int i=1; i<=n; i++)
        scanf("%d", val+i);
    for(int i=1; i<n; i++) {
        int a, b; scanf("%d %d", &a, &b);
        edge[a].push_back(b);
        edge[b].push_back(a);
    }
    fill(vis, vis+n+1, false);
    divide(1);
    for(int i=1; i<=n; i++)
        for(int j=0; j<maxl; j++)
            ans[j] = mod(ans[j] + dp[i][j]);
    int q; scanf("%d", &q);
    for(int i=0; i<q; i++) {
        int t; scanf("%d", &t);
        printf("%d\n", ans[t]);
    }
    return 0;
}

