#include<bits/stdc++.h>
using namespace std;
const int maxn = 1e2;
const int inf  = 1e9;
int dp[maxn*maxn+10];
int c[maxn+10],v[maxn+10];
void work() {
	int n,C;
	scanf("%d%d",&n,&C);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&c[i],&v[i]);
	for(int i=1;i<=maxn*maxn;i++) dp[i]=inf;
	for(int i=1;i<=n;i++)
		for(int j=maxn*maxn;j>=v[i];j--)
			dp[j]=min(dp[j],dp[j-v[i]]+c[i]);
	int ans=0;
	for(int i=1;i<=maxn*maxn;i++)
		if(dp[i]<=C) ans=i;
	printf("%d\n",ans);
	return ;
}
int main() {
	int t;
	scanf("%d",&t);
	while(t--) work();
	return 0;
}
