#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define pii pair<int, int>
#define pb push_back
#define mk make_pair
#define fi first
#define se second
#define ALL(A) A.begin(), A.end()
#define sqr(x) ((x)*(x))
#define sc(x) scanf("%d", &x)
#define pr(x) printf(">>>"#x":%d\n", x)
#define fastio ios::sync_with_stdio(0),cin.tie(0)
#define frein freopen("in.txt", "r", stdin)
#define freout freopen("out.txt", "w", stdout)
#define debug cout<<">>>STOP"<<endl
const int INF = 0x3f3f3f3f;
const long double eps = 1e-10;
template<class T> T gcd(T a, T b){if(!b)return a;return gcd(b,a%b);}
const int maxn = 2e4+10;
const int maxm = 2e6+10;
struct edge
{
    int to, nxt;
    long double cap;
}es[maxm];
int head[maxn], iter[maxn], lev[maxn];
int a[maxn];
int n, cnt;


void init()
{
    cnt = 0;
    memset(head, -1, sizeof(head));
}

void add_edge(int u, int v, long double cap)
{
    //printf("add(%d,%d,%LF)\n", u, v, cap);
    es[cnt].to = v, es[cnt].cap = cap, es[cnt].nxt = head[u];
    head[u] = cnt++;
    es[cnt].to = u, es[cnt].cap = 0, es[cnt].nxt = head[v];
    head[v] = cnt++;
}

bool bfs(int s, int t)
{
    memset(lev, -1, sizeof(lev));
    lev[s] = 1;
    queue<int> q;
    q.push(s);
    while(!q.empty()){
        int u = q.front(); q.pop();
        for(int i = head[u]; ~i; i = es[i].nxt){
            edge &e = es[i];
            if(e.cap > eps && lev[e.to] < 0){
                lev[e.to] = lev[u]+1;
                if(e.to == t)return 1;
                q.push(e.to);
            }
        }
    }
    return 0;
}

long double dfs(int v, int t, long double f)
{
    if(v == t)return f;
    long double ret = 0;
    for(int &i = iter[v]; ~i; i = es[i].nxt){
        edge &e = es[i];
        if(e.cap > eps && lev[e.to] == lev[v]+1){
            long double d = dfs(e.to, t, min(e.cap, f-ret));
            if(d > eps){
                e.cap -= d;
                es[i^1].cap += d;
                ret += d;
                if(ret + eps >= f)break;
            }
        }
    }
    if(ret < eps)lev[v] = 0;
    return ret;
}

long double max_flow(int s, int t)
{
    long double ret = 0;
    while(bfs(s, t)){
        memcpy(iter, head, sizeof(head));
        ret += dfs(s, t, INF);
        //printf("flow->ret=%LF\n", ret);
    }
    return ret;
}

bool solve(long double m)
{
    init();
    int src = n+n*n+1, dst = src+1;
    for(int i = 1; i <= n; i++)add_edge(i, dst, m);
    int num = 0;
    for(int i = 1; i <= n; i++){
        for(int j = i+1; j <= n; j++){
            if(a[i]%a[j] == 0 || a[j]%a[i] == 0){
                num++;
                add_edge(src, n+num, 1);
                add_edge(n+num, i, INF);
                add_edge(n+num, j, INF);
            }
        }
    }
    long double ret = num-max_flow(src, dst);
    //printf("m=%Lf ret=%Lf\n", m, ret);
    return ret > eps;
}

int main()
{
    sc(n);
    for(int i = 1; i <= n; i++)sc(a[i]);
    long double l = 0, r = n*n, ans = 0;
    while(l + eps < r){
        long double m = (l+r)/2;
        if(solve(m)){
            ans = m;
            l = m;
        }
        else r = m;
    }
    solve(ans);
    printf("%.10Lf\n", ans);
    return 0;
}

