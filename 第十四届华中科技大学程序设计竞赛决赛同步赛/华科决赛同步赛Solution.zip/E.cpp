#include <bits/stdc++.h>
using namespace std;
#define zeros(a,n) memset(a,0,(n)*sizeof(a[0]))
#define next HKjournalist
typedef long long LL;
typedef unsigned long long ULL;
const LL modn = 2e9+7;

const int maxn = 2e5+9;
const int sigma = 11;
int p[maxn] = {-1, 1, -1, 1}, t[maxn] = {-1, -1, 1, 1, 4, 1};
int next[maxn];
int s0[maxn], s1[maxn];
int pre[sigma];

void getnext(int p[], int len, int next[])
{
    next[0] = -1;
    int i = 1, j = 0;
    while(i<len) {
        while(~j && (j-p[i]<0?(p[j]!=-1):(p[i]!=p[j])))
            j = next[j];
        next[++i] = ++j;
    }
}

int match(int p[], int pl, int next[], int t[], int tl)
{
    int ans = 0;
    int j = 0;
    for(int i=0; i<tl; i++) {
        while(~j && (j-t[i]<0?(p[j]!=-1):(t[i]!=p[j])))
            j = next[j];
        j++;
        if(j == pl) ans++;
    }
    return ans;
}

int main()
{
    int n, k; scanf("%d %d", &n, &k);
    for(int i=0; i<n; i++)
        scanf("%d", s0+i);
    int m; scanf("%d", &m);
    for(int i=0; i<m; i++)
        scanf("%d", s1+i);
    memset(pre, -1, sizeof(pre));
    for(int i=0; i<m; i++) {
        p[i] = pre[s1[i]]==-1?-1:(i-pre[s1[i]]);
        pre[s1[i]] = i;
    }
    p[m] = -2;
    getnext(p, m, next);
    // scanf("%s", s);
    // int tl = strlen(s);
    memset(pre, -1, sizeof(pre));
    for(int i=0; i<n; i++) {
        t[i] = pre[s0[i]]==-1?-1:(i-pre[s0[i]]);
        pre[s0[i]] = i;
    }
    t[n] = -3;
#ifdef SONG
    printf("n: %d, m: %d\n", n, m);
#endif
    printf("%d\n", match(p, m, next, t, n));
    return 0;
}

