#include<cstdio>
const int N=200005;
struct tree{
  int l,r,count,tag;
}tr[N*4];
int a[N];
void updata(int now){
  int lch=now<<1,rch=lch+1;
  tr[now].l=tr[lch].l;
  tr[now].r=tr[rch].r;
  if(tr[lch].r==tr[rch].l) tr[now].count=tr[lch].count+tr[rch].count-1;
  else tr[now].count=tr[lch].count+tr[rch].count;
}

void pushdown(int now){
  int lch=now<<1,rch=lch+1;
  if(tr[now].tag!=-1){
    tr[lch].tag=tr[now].tag;
    tr[rch].tag=tr[now].tag;
    tr[lch].count=1;
    tr[rch].count=1;
    tr[lch].l=tr[lch].r=tr[now].tag;
    tr[rch].l=tr[rch].r=tr[now].tag;
    tr[now].tag=-1;
  }
}

void build(int now,int l,int r){
  if(l==r){
    tr[now].l=a[l];
    tr[now].r=a[l];
    tr[now].count=1;
    tr[now].tag=-1;
    return;
  }
  int lch=now<<1,rch=lch+1;
  int mid=(l+r)>>1;
  build(lch,l,mid);
  build(rch,mid+1,r);
  updata(now);
  tr[now].tag=-1;
}

void change(int now,int L,int R,int l,int r,int x){
  if(l==L&&r==R){
    tr[now].l=x;
    tr[now].r=x;
    tr[now].tag=x;
    tr[now].count=1;
    //tr[now].timer=timer;
    return;
  }
  pushdown(now);
  int lch=now<<1,rch=lch+1;
  int mid=(L+R)>>1;
  if(r<=mid) change(lch,L,mid,l,r,x);
  else if(l>mid) change(rch,mid+1,R,l,r,x);
  else{
    change(lch,L,mid,l,mid,x);
    change(rch,mid+1,R,mid+1,r,x);
  }
  updata(now);
}

int query(int now,int L,int R,int l,int r){
  if(L==l&&R==r){
    return tr[now].count;
  }
  int lch=now<<1,rch=lch+1;
  int mid=(L+R)>>1;
  pushdown(now);
  if(r<=mid) return query(lch,L,mid,l,r);
  else if(l>mid) return query(rch,mid+1,R,l,r);
  else{
    int ans1=query(lch,L,mid,l,mid);
    int ans2=query(rch,mid+1,R,mid+1,r);
    int ans=ans1+ans2;
    if(tr[lch].r==tr[rch].l) ans--;
    return ans;
  }
}

int main(){
  int n,m;
  scanf("%d%d",&n,&m);
  for(int i = 1;i<=n;i++) scanf("%d",&a[i]);
  build(1,1,n);
  for(int i =1;i<=m;i++){
    int opt;
    scanf("%d",&opt);
    if(opt==1){
      int l,r,x;
      scanf("%d%d%d",&l,&r,&x);
      change(1,1,n,l,r,x);
    }
    if(opt==2){
      int l,r,k;
      scanf("%d%d%d",&l,&r,&k);
      int liceCount=query(1,1,n,l,r);
      int linkCount=(r-l+1)-liceCount;
      if(linkCount<=k) printf("%d\n",linkCount+liceCount);
      else printf("%d\n",k+liceCount);
    }
  }
}
