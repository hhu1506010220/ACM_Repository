#include <bits/stdc++.h>
using namespace std;
#define zeros(a,n) memset(a,0,(n)*sizeof(a[0]))
typedef long long LL;
typedef unsigned long long ULL;

const LL g = 3;
const LL modn = 998244353;

LL mod(LL x) { return x<0?x+modn:x<modn?x:x-modn; }

LL quickpow(LL a, LL n, LL p)
{
    LL ans = 1;
    while(n) {
        if(n & 1) ans = ans * a % p;
        a = a * a % p;
        n >>= 1;
    }
    return ans;
}

void ntt(LL x[], int len, int on)
{
    for(int i=1, j=len/2; i<len-1; i++) {
        if(i<j) swap(x[i], x[j]);
        int k = len/2;
        while(j >= k) {
            j -= k;
            k >>= 1;
        }
        if(j < k) j += k;
    }
    for(int k=1; k<len; k<<=1) {
        LL wm = quickpow(g, modn/2/k, modn);
        for(int i=0; i<len; i+=2*k) {
            LL w = 1;
            for(int j=0; j<k; j++) {
                LL u = x[i+j];
                LL v = w*x[i+j+k]%modn;
                x[i+j] = mod(u+v);
                x[i+j+k] = mod(u-v);
                w = w*wm%modn;
            }
        }
    }
    if(on == -1) {
        reverse(x+1, x+len);
        LL inv = quickpow(len, modn-2, modn);
        for(int i=0; i<len; i++)
            x[i] = x[i]*inv%modn;
    }
}

const int maxn = 3000 + 9, maxl = 4096;

vector<int> edge[maxn];
LL dp[maxn][maxl];
int val[maxn];
int ans[maxl];

void dfs(int x, int f = 0)
{
    fill_n(dp[x], maxl, 0);
    dp[x][val[x]] = 1;
    for(int y: edge[x]) {
        if(y == f) continue;
        dfs(y, x);
        dp[y][0] = mod(dp[y][0] + 1);
        ntt(dp[x], maxl, 1);
        ntt(dp[y], maxl, 1);
        for(int i=0; i<maxl; i++)
            dp[x][i] = dp[x][i] * dp[y][i] % modn;
        ntt(dp[x], maxl, -1);
        fill(dp[x] + maxl/2, dp[x] + maxl, 0);
    }
    for(int i=0; i<maxl/2; i++)
        ans[i] = mod(ans[i] + dp[x][i]);
}

int main()
{
    int n; scanf("%d", &n);
    for(int i=1; i<=n; i++)
        scanf("%d", val+i);
    for(int i=1; i<n; i++) {
        int a, b; scanf("%d %d", &a, &b);
        edge[a].push_back(b);
        edge[b].push_back(a);
    }
    fill(ans, ans + maxl/2, 0);
    dfs(1);
    int q; scanf("%d", &q);
    for(int i=0; i<q; i++) {
        int t; scanf("%d", &t);
        printf("%d\n", ans[t]);
    }
    for(int i=1; i<=n; i++)
        edge[i].clear();
    return 0;
}

