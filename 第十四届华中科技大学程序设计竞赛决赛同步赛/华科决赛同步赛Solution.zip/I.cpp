#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>

#define maxn 1000+5
#define INF 0x3f3f3f3f

using namespace std;

typedef long long ll;

ll a[maxn], ans[maxn];
ll n, m;

ll extend_gcd(ll a, ll b, ll &x, ll &y) {
	if (b == 0) {
		x = 1, y = 0;
		return a;
	}
	else {
		ll r = extend_gcd(b, a%b, y, x);
		y -= (ll)x * (a / b);
		return r;
	}
}

ll getans(ll now, ll pos, ll q) {
	ll x, y;
	ll gcd = extend_gcd(now, a[pos], x, y);
	if (pos == n) {
		if (q%gcd != 0) return INF;
		ans[pos] =(ll) y * (q / gcd);
		if (pos == 2) ans[1] = (ll)x * (q / gcd);
		return (ll)x * (q / gcd)*now;
	}
	ll t = getans(gcd, pos + 1, q);
	if (t == INF || t % gcd != 0) return INF;
	ans[pos] =(ll) y * (t / gcd);
	if (pos == 2) ans[1] = x * (t / gcd);
	return x * (t / gcd)*now;
}

int main() {
	scanf("%lld%lld", &n, &m);
	for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);
	for (int i = 1; i <= m; i++) {
		ll x, t;
		scanf("%lld", &x);
		t = getans(a[1], 2, x);
		if (t == INF) { puts("NO"); }
		else {
			ans[1] = t / a[1];
			for (int j = 1; j <= n; j++){
			 printf("%lld", ans[j]);
			if(j!=n)printf(" ");
			}
			printf("\n");
		}
	}
	return 0;
}
