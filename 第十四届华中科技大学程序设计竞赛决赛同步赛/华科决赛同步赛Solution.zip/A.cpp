#include<cstdio>
#include<cstring>
#include<iostream>

using namespace std;

const int maxn=1e5+10;

int n,m,l,r,k,fl,cnt;
int f[maxn*2][32];

int find(int t,int k)
{
	int p=t,r;
	while(t!=f[t][k])t=f[t][k];
	while(p!=t)r=f[p][k],f[p][k]=t,p=r;
	return t;
}

void unio(int l,int r,int j)
{
	if(find(l,j)!=find(r,j))
		f[find(l,j)][j]=find(r,j);
}

int main()
{
	scanf("%d%d",&n,&m);
	for(int i=0;i<=n*2+1;i++)
		for(int j=0;j<=30;j++)
			f[i][j]=i;

	for(int i=1;i<=m;i++)
	{
		fl=0;
		scanf("%d%d%d",&l,&r,&k);l--;
		
		for(int j=0;j<=30;j++)
			if((k&(1LL<<j))!=0&&(find(l,j)==find(r,j)||find(l+n+1,j)==find(r+n+1,j)))
				{printf("%d\n",i);fl=1;break;}
			else if((k&(1LL<<j))==0&&(find(l,j)==find(n+r+1,j)||find(r,j)==find(n+l+1,j)))
				{printf("%d\n",i);fl=1;break;}
		if(fl)continue;
		
		cnt++;
		for(int j=0;j<=30;j++)
			if((k&(1LL<<j))!=0)unio(l,r+n+1,j),unio(r,l+n+1,j);
			else unio(l,r,j),unio(l+n+1,r+n+1,j);
	}
	
	if(cnt==m)printf("-1");
	
	return 0;
}
